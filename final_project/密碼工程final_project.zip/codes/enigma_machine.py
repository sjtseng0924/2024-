import random
import string
from collections import Counter

class EnigmaMachine:
    def __init__(self, rotors, reflector):
        self.rotors = rotors
        self.reflector = reflector
        self.plugboard = {}
        self.rotor_positions = [0] * len(rotors)

    def set_plugboard(self, settings):
        self.plugboard = {pair[0].upper(): pair[1].upper() for pair in settings}
        self.plugboard.update({pair[1].upper(): pair[0].upper() for pair in settings})

    def encipher(self, text):
        text = text.upper()
        result = ''
        for char in text:
            if char == ' ':
                result += ' '  # 保留空格
                continue
            if char in self.plugboard:
                char = self.plugboard[char]
            char, forward_steps = self.pass_through_rotors(char, forward=True)
            char = self.reflector[ord(char) - 65]
            char, backward_steps = self.pass_through_rotors(char, forward=False)
            if char in self.plugboard:
                char = self.plugboard[char]
            result += char
            self.advance_rotors()
        return result

    def pass_through_rotors(self, char, forward=True):
        idx = ord(char) - 65
        steps = [char]
        for i in range(len(self.rotors)):
            rotor = self.rotors[i] if forward else self.rotors[-i - 1]
            position = self.rotor_positions[i] if forward else self.rotor_positions[-i - 1]
            if forward:
                idx = (ord(rotor[(idx + position) % 26]) - 65 ) % 26
            else:
                idx = (rotor.index(chr((idx) % 26 + 65)) - position) % 26
            steps.append(chr(idx + 65))
        return chr(idx + 65), steps

    def advance_rotors(self):
        self.rotor_positions[0] += 1
        for i in range(len(self.rotors) - 1):
            if self.rotor_positions[i] == 26:
                self.rotor_positions[i] = 0
                self.rotor_positions[i + 1] += 1

# 定義轉子和反射器
rotors = [
    "EKMFLGDQVZNTOWYHXUSPAIBRCJ",  # Rotor I
    "AJDKSIRUXBLHWTMCQGZNPYFVOE",  # Rotor II
    "BDFHJLCPRTXVZNYEIWGAKMUSQO",  # Rotor III
    "ESOVPZJAYQUIRHXLNFTGKDCMWB",  # Rotor IV
    "VZBRGITYUPSDNHLXAWMJQOFECK"   # Rotor V
]
reflector = "YRUHQSLDPXNGOKMIEBFZCWVJAT"  # Reflector B

# 讓用戶選擇轉子
print("請選擇三個轉子（1-5）：")
for i in range(len(rotors)):
    print(f"{i+1}. Rotor {i+1}")

selected_rotors = []
while len(selected_rotors) < 3:
    selections = input("請輸入要選擇的轉子編號（例如:1 3 5）：").split()
    invalid_selection = False
    for selection in selections:
        if not selection.isdigit() or int(selection) < 1 or int(selection) > len(rotors) or rotors[int(selection)-1] in selected_rotors:
            print("無效的選擇")
            invalid_selection = True
            break
    if invalid_selection:
        continue
    selected_rotors = [rotors[int(selection)-1] for selection in selections]

# 讓用戶設定每個轉子的初始位置
print("請設定每個轉子的初始位置（1-26）：")
initial_positions = []
for i in range(len(selected_rotors)):
    position = input(f"請設定轉子 {i+1} 的初始位置：")
    while not position.isdigit() or int(position) < 1 or int(position) > 26:
        print("無效的位置")
        position = input(f"請設定轉子 {i+1} 的初始位置：")
    initial_positions.append(int(position) - 1)

# 讓用戶設定接線板
plugboard_settings = input("請輸入接線板設定（例如:AB CD EF）（最多十組）：").strip().split()
if len(plugboard_settings) > 10:
    print("接線板設定組數超過十組，僅取前十組設定。")
    plugboard_settings = plugboard_settings[:10]
plugboard_settings = [pair.upper() for pair in plugboard_settings if len(pair) == 2 and pair.isalpha()]

# 創建Enigma機
enigma = EnigmaMachine(selected_rotors, reflector)
enigma.set_plugboard(plugboard_settings)

# 設定每個轉子的初始位置
enigma.rotor_positions = initial_positions

# 加密文本
plaintext = input("請輸入要加密的文本：")
ciphertext = enigma.encipher(plaintext)
print(f"加密後的文本：{ciphertext}")
input("按下回車鍵結束程式...")
