# Diffie-Hellman Key Exchange Example

This project implements the Diffie-Hellman Key Exchange (DHKE) algorithm and uses the shared key to encrypt and decrypt messages.

## Requirements

- Python 3.x

## Files

- `diffie_hellman_encryption.py`: Contains the implementation of the Diffie-Hellman Key Exchange algorithm and message encryption and decryption.

## Usage

1. Clone this repository or download the `diffie_hellman_encryption.py` file.
2. Open a terminal and navigate to the directory containing `diffie_hellman_encryption.py`.
3. Run the script using Python:

   ```sh
   python diffie_hellman_encryption.py
