from collections import defaultdict
import itertools
import string

class EnigmaMachine:
    def __init__(self, rotors, reflector, rotor_positions):
        self.rotors = rotors
        self.reflector = reflector
        self.plugboard = {}
        self.rotor_positions = rotor_positions

    def set_plugboard(self, settings):
        self.plugboard = {pair[0].upper(): pair[1].upper() for pair in settings}
        self.plugboard.update({pair[1].upper(): pair[0].upper() for pair in settings})

    def encipher(self, text):
        text = text.upper()
        result = ''
        for char in text:
            if char == ' ':
                result += ' '  # 保留空格
                continue
            if char in self.plugboard:
                char = self.plugboard[char]
            # print(f"Plugboard output: {char}")
            char, forward_steps = self.pass_through_rotors(char, forward=True)
            # print(f"Forward through rotors: {forward_steps}")
            char = self.reflector[ord(char) - 65]
            # print(f"Reflector output: {char}")
            char, backward_steps = self.pass_through_rotors(char, forward=False)
            # print(f"Backward through rotors: {backward_steps}")
            if char in self.plugboard:
                char = self.plugboard[char]
            # print(f"Plugboard output: {char}")
            result += char
            self.advance_rotors()
        return result

    def pass_through_rotors(self, char, forward=True):
        idx = ord(char) - 65
        steps = [char]
        for i in range(len(self.rotors)):
            rotor = self.rotors[i] if forward else self.rotors[-i - 1]
            position = self.rotor_positions[i] if forward else self.rotor_positions[-i - 1]
            if forward:
                idx = (ord(rotor[(idx + position) % 26]) - 65 ) % 26
            else:
                idx = (rotor.index(chr((idx) % 26 + 65)) - position) % 26
            steps.append(chr(idx + 65))
        return chr(idx + 65), steps

    def advance_rotors(self):
        self.rotor_positions[0] += 1
        for i in range(len(self.rotors) - 1):
            if self.rotor_positions[i] == 26:
                self.rotor_positions[i] = 0
                self.rotor_positions[i + 1] += 1

# 文本中生成 bigram 頻率的函數
def read_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as file:
        return file.read()

def calculate_bigram_frequencies(text):
    text = text.upper().replace(' ', '')  # 轉換成大寫並去除空格
    text = ''.join(filter(lambda x: x in string.ascii_uppercase, text))  # 保留字母（捨去標點符號）
    bigram_freq = defaultdict(int)
    total_bigrams = 0

    for i in range(len(text) - 1):
        bigram = text[i:i + 2]
        bigram_freq[bigram] += 1
        total_bigrams += 1

    # 轉換成頻率
    for bigram in bigram_freq:
        bigram_freq[bigram] /= total_bigrams

    return bigram_freq

def save_bigram_freq_to_file(bigram_freq, output_file):
    with open(output_file, 'w', encoding='utf-8') as file:
        for bigram, freq in bigram_freq.items():
            file.write(f"{bigram} {freq}\n")

def load_bigram_freq_from_file(input_file):
    bigram_freq = defaultdict(float)
    with open(input_file, 'r', encoding='utf-8') as file:
        for line in file:
            bigram, freq = line.split()
            bigram_freq[bigram] = float(freq)
    return bigram_freq

# 計算 n-gram 連續性分數
def calculate_ngram_score(text, ngram_freq):
    text = text.upper().replace(' ', '')
    score = 0
    for i in range(len(text) - 1):
        ngram = text[i:i + 2]
        if ngram in ngram_freq:
            score += ngram_freq[ngram]
    return score

# 暴力破解
def brute_force_decrypt(ciphertext, ngram_freq):
    best_score = float('-inf')
    best_decryption = None
    best_positions = None
    for rotor_positions in itertools.product(range(26), repeat=3):
        enigma_try = EnigmaMachine(selected_rotors, reflector, list(rotor_positions))
        decrypted_message = enigma_try.encipher(ciphertext)
        score = calculate_ngram_score(decrypted_message, ngram_freq)
        if score > best_score:
            best_score = score
            best_decryption = decrypted_message
            best_positions = rotor_positions
    best_positions = tuple(x + 1 for x in best_positions)
    print(f"Best match found: {best_decryption}")
    print(f"rotor positions : {best_positions}")
    return best_decryption

# 定義轉子和反射器
rotors = [
    "EKMFLGDQVZNTOWYHXUSPAIBRCJ",  # Rotor I
    "AJDKSIRUXBLHWTMCQGZNPYFVOE",  # Rotor II
    "BDFHJLCPRTXVZNYEIWGAKMUSQO",  # Rotor III
    "ESOVPZJAYQUIRHXLNFTGKDCMWB",  # Rotor IV
    "VZBRGITYUPSDNHLXAWMJQOFECK"   # Rotor V
]
reflector = "YRUHQSLDPXNGOKMIEBFZCWVJAT"  # Reflector B


# 讓用戶選擇轉子
print("請選擇三個轉子（1-5）：")
for i in range(len(rotors)):
    print(f"{i+1}. Rotor {i+1}")

selected_rotors = []
while len(selected_rotors) < 3:
    selections = input("請輸入要選擇的轉子編號（例如:1 3 5）：").split()
    invalid_selection = False
    for selection in selections:
        if not selection.isdigit() or int(selection) < 1 or int(selection) > len(rotors) or rotors[int(selection)-1] in selected_rotors:
            print("無效的選擇")
            invalid_selection = True
            break
    if invalid_selection:
        continue
    selected_rotors = [rotors[int(selection)-1] for selection in selections]

# 讓用戶設定每個轉子的初始位置
print("請設定每個轉子的初始位置（1-26）：")
initial_positions = []
for i in range(len(selected_rotors)):
    position = input(f"請設定轉子 {i+1} 的初始位置：")
    while not position.isdigit() or int(position) < 1 or int(position) > 26:
        print("無效的位置")
        position = input(f"請設定轉子 {i+1} 的初始位置：")
    initial_positions.append(int(position) - 1)

# 讓用戶設定接線板
plugboard_settings = input("請輸入接線板設定（例如:AB CD EF）（最多十組）：").strip().split()
if len(plugboard_settings) > 10:
    print("接線板設定組數超過十組，僅取前十組設定。")
    plugboard_settings = plugboard_settings[:10]
plugboard_settings = [pair.upper() for pair in plugboard_settings if len(pair) == 2 and pair.isalpha()]

# 創建Enigma機
enigma = EnigmaMachine(selected_rotors, reflector, initial_positions)
enigma.set_plugboard(plugboard_settings)

# 加密文本
plaintext = "COMMANDTHISISBRAVOTEAMWEHAVESECUREDTHEOBJECTIVEANDAREAWAITINGFURTHERORDERSNOHOSTILESINSIGHTPLEASEADVISEONNEXTSTEPSOVER"
ciphertext = enigma.encipher(plaintext)
print(f"Plaintext: {plaintext}")
print(f"Ciphertext: {ciphertext}")

# 生成 bigram 頻率字典
corpus_file = 'shakespeare.txt'  # 使用莎士比亞的作品
corpus_text = read_file(corpus_file)
BIGRAM_FREQ = calculate_bigram_frequencies(corpus_text)

# 保存 bigram 頻率字典到文件
output_file = 'bigram_freq.txt'
save_bigram_freq_to_file(BIGRAM_FREQ, output_file)

# 使用 bigram 频率字典进行暴力破解
decrypted_message = brute_force_decrypt(ciphertext, BIGRAM_FREQ)
input("按下回車鍵結束程式...")
