import random
import string

def generate_cipher():
    letters = list(string.ascii_uppercase)
    shuffled_letters = letters.copy()
    random.shuffle(shuffled_letters)
    cipher = dict(zip(letters, shuffled_letters))
    return cipher

def encrypt(message, cipher):
    message = ''.join(char for char in message.upper() if char in string.ascii_uppercase)
    return ''.join(cipher.get(char, char) for char in message)

cipher = generate_cipher()

letters = string.ascii_uppercase
encrypted_letters = ''.join(cipher[letter] for letter in letters)
print("生成的加密對照表:")
print(' '.join(letters))
print(' '.join(encrypted_letters))

message = input("\n請輸入要加密的文字: ")

encrypted_message = encrypt(message, cipher)
print("加密文字:", encrypted_message)
input("按下回車鍵結束程式...")