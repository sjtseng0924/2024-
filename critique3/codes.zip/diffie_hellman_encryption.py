import random
from hashlib import sha256

# Function to check if a number is prime
def is_prime(num):
    if num < 2:
        return False
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            return False
    return True

# Function to validate the inputs q and alpha
def validate_inputs(q, alpha):
    if not is_prime(q):
        raise ValueError("q must be a prime number.")
    if not (1 < alpha < q):
        raise ValueError("alpha must be between 1 and q.")

# Function to generate private and public keys
def generate_keys(q, alpha):
    private_key = random.randint(1, q-1)
    public_key = pow(alpha, private_key, q)
    return private_key, public_key

# Function to compute the shared key
def compute_shared_key(private_key, other_public_key, q):
    shared_key = pow(other_public_key, private_key, q)
    return shared_key

# Function to encrypt a message using the shared key
def encrypt_message(shared_key, message):
    key = sha256(str(shared_key).encode()).digest()
    encrypted_message = bytearray()
    for i in range(len(message)):
        encrypted_message.append(message[i] ^ key[i % len(key)])
    return encrypted_message

# Function to decrypt a message using the shared key
def decrypt_message(shared_key, encrypted_message):
    key = sha256(str(shared_key).encode()).digest()
    decrypted_message = bytearray()
    for i in range(len(encrypted_message)):
        decrypted_message.append(encrypted_message[i] ^ key[i % len(key)])
    return decrypted_message

def main():
    try:
        # User input for prime number q and primitive root alpha
        q = int(input("Please input a prime number q: "))
        alpha = int(input("Please input a primitive root alpha: "))
        validate_inputs(q, alpha)
    except ValueError as e:
        print(e)
        return
    
    # User A generates their keys
    private_key_a, public_key_a = generate_keys(q, alpha)
    print(f"User A's private key: {private_key_a}")
    print(f"User A's public key: {public_key_a}")
    
    # User B generates their keys
    private_key_b, public_key_b = generate_keys(q, alpha)
    print(f"\nUser B's private key: {private_key_b}")
    print(f"User B's public key: {public_key_b}")
    
    # Users exchange public keys and compute the shared key
    shared_key_a = compute_shared_key(private_key_a, public_key_b, q)
    shared_key_b = compute_shared_key(private_key_b, public_key_a, q)
    
    print(f"\nUser A's shared key: {shared_key_a}")
    print(f"User B's shared key: {shared_key_b}")
    
    assert shared_key_a == shared_key_b, "Shared keys do not match!"
    print("\nKey exchange successful! Both users have the same shared key.\n")
    
    # Example messages
    messages = [
        "Hello, this is a secret message.",
        "Short msg",
        "This message is longer than the others and should still be encrypted correctly.",
        "",
        "Another example with different content."
    ]
    
    for message in messages:
        print(f"Original message: {message}")
        encrypted_message = encrypt_message(shared_key_a, message.encode())
        print(f"Encrypted message: {encrypted_message}")
        decrypted_message = decrypt_message(shared_key_b, encrypted_message)
        print(f"Decrypted message: {decrypted_message.decode()}")
        print("----")

if __name__ == "__main__":
    main()