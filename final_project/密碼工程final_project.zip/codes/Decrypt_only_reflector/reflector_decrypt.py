import random
import string
import math

# 創建空字典
def create_empty_dict(known_chars):
    empty_dict = {}
    for i in known_chars:
        for j in known_chars:
            empty_dict.setdefault(i, {})[j] = 0    
    return empty_dict

# 創建字符對計數字典
def create_count_dict(text, known_chars):
    count_dict = create_empty_dict(known_chars)
    for i in range(len(text) - 1):
        char_a = text[i]
        char_b = text[i+1]
        if char_a in known_chars and char_b in known_chars:
            count_dict[char_a][char_b] += 1
    return count_dict

# 創建字符對頻率字典
def create_perc_dict(count_dict, known_chars):
    perc_dict = create_empty_dict(known_chars)
    for i in known_chars:
        total_count = sum(count_dict[i].values())
        for j in known_chars:
            letter_perc = (count_dict[i][j] + 1) / (total_count + len(known_chars))  # 使用加1平滑
            perc_dict[i][j] = math.log(letter_perc)
    return perc_dict

# 從文件中讀取文本並創建頻率字典
known_chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
with open('shakespeare.txt', encoding="utf8") as file:
    text = file.read().upper()

# 過濾非英文字母字符
text = ''.join(char for char in text if char in string.ascii_uppercase)
    
count_dict = create_count_dict(text, known_chars)
perc_dict = create_perc_dict(count_dict, known_chars)

# 使用映射解密文本
def decrypt_with_mapping(ciphertext, mapping):
    inverse_mapping = {v: k for k, v in mapping.items()}
    return ''.join(inverse_mapping.get(char, char) for char in ciphertext)

# 計算文本字符對的得分
def score_likelihood(decrypted_text, perc_dict):
    total_likelihood = 0
    for i in range(len(decrypted_text) - 1):
        pair_likelihood = perc_dict.get(decrypted_text[i], {}).get(decrypted_text[i+1], -100)
        total_likelihood += pair_likelihood
    return total_likelihood

# 對映射進行小幅度改動
def shuffle_pair(current_dict):
    a, b = random.sample(list(current_dict.keys()), 2)
    proposed_dict = current_dict.copy()
    proposed_dict[a], proposed_dict[b] = proposed_dict[b], proposed_dict[a]
    return proposed_dict

# 計算新映射的得分
def eval_proposal(proposed_score, current_score, temperature):
    diff = proposed_score - current_score
    accept_prob = math.exp(diff / temperature)
    return accept_prob >= random.uniform(0, 1)

# MCMC解密
def decrypt_MCMC(ciphertext, perc_dict, iterations=20000, temperature=1.0, verbose=False):
    ciphertext = ciphertext.upper()
    
    current_mapping = {k: v for k, v in zip(string.ascii_uppercase, string.ascii_uppercase)}
    current_decryption = decrypt_with_mapping(ciphertext, current_mapping)
    current_score = score_likelihood(current_decryption, perc_dict)
    
    best_score = current_score
    best_mapping = current_mapping
    best_decryption = current_decryption

    for i in range(iterations):
        proposed_mapping = shuffle_pair(current_mapping)
        proposed_decryption = decrypt_with_mapping(ciphertext, proposed_mapping)
        proposed_score = score_likelihood(proposed_decryption, perc_dict)
        
        if eval_proposal(proposed_score, current_score, temperature):
            current_mapping = proposed_mapping
            current_decryption = proposed_decryption
            current_score = proposed_score
            
            if current_score > best_score:
                best_score = current_score
                best_mapping = current_mapping
                best_decryption = current_decryption
        
        if verbose and i % 1000 == 0:
            print(f"Iteration: {i}, Score: {current_score}, Best Score: {best_score}")
    
    return best_decryption, best_mapping

ciphertext = input("\n請輸入要解密的文字: ")
decrypted_text, final_mapping = decrypt_MCMC(ciphertext, perc_dict)
print("最終加密對照表:")
print(' '.join(string.ascii_uppercase))
print(' '.join(final_mapping[char] for char in string.ascii_uppercase))
print("\n解密文本:")
print(decrypted_text)
input("按下回車鍵結束程式...")
